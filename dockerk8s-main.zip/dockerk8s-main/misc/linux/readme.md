# TAR commands
https://www.tecmint.com/18-tar-command-examples-in-linux/

# Tee
wc -l readme.md| tee lines.txt

# Search and replace
:%s/old/new/g