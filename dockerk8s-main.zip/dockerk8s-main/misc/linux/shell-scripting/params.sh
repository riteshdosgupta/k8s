#!/bin/sh
name=$1
place=$2
echo "Hello $1, happy to know that you are from $2"
