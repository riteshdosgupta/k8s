#!/bin/sh
option=$1
case $option in 
	0) echo "You have choosen option 0" ;;
	1) echo "You have choosen option 1" ;;
	*) echo "You have not choosen any option" ;;
esac
