#!/bin/sh
echo "Enter your name"
read name
echo "Hello $name, glad to meet you!"
read age
echo "Hello $name, you are $age years old!"
