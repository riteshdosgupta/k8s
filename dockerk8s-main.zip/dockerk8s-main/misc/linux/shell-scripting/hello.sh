#!/bin/bash

title="My first shell script"
echo $title
