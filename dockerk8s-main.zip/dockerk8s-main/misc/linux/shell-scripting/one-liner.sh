#!/bin/bash

# i=0;while true ; do i=$i+1; echo "Welcome $i times"; [[ $i -gt 3 ]] && break  ; done

for i in {1..5}; do echo "Welcome $i times"; done
