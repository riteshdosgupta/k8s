kubeadm join 10.0.0.10:6443 --token h5bcaw.5623ecmk87qt4gka --discovery-token-ca-cert-hash sha256:479abe26496952ab06380026b0401cf5863dcd4280f8dabb0a5078f975064bf1 
