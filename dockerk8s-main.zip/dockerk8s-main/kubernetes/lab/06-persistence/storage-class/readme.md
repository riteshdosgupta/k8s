# OpenEBS volume 
kubectl apply -f https://openebs.github.io/charts/openebs-operator.yaml
