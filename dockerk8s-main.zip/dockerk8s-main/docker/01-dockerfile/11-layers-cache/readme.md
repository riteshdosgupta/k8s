For dockerfile example, please browse 
Pre-optimized Dockerfile: https://github.com/brainupgrade-in/weather/blob/monolith/docker-preopt/Dockerfile
Optimized Dockerfile: https://github.com/brainupgrade-in/weather/blob/monolith/Dockerfile